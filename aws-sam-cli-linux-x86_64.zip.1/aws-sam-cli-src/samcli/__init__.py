"""
SAM CLI version
"""

__version__ = "1.146.0"
